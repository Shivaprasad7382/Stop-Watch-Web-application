let timer = null;
let isRunning = false;
let seconds = 0, minutes = 0, hours = 0;
let lapCount = 0;

function updateDisplay() {
    document.getElementById("display").textContent =
        `${String(hours).padStart(2, '0')}:` +
        `${String(minutes).padStart(2, '0')}:` +
        `${String(seconds).padStart(2, '0')}`;
}

function startTimer() {
    seconds++;
    if (seconds === 60) { seconds = 0; minutes++; }
    if (minutes === 60) { minutes = 0; hours++; }
    updateDisplay();
}

function startStop() {
    if (isRunning) {
        clearInterval(timer);
    } else {
        timer = setInterval(startTimer, 1000);
    }
    isRunning = !isRunning;
}

function reset() {
    clearInterval(timer);
    isRunning = false;
    seconds = minutes = hours = lapCount = 0;
    document.getElementById("laps").innerHTML = "";
    localStorage.removeItem("laps");
    updateDisplay();
}

function lap() {
    if (!isRunning) return;

    lapCount++;
    const time = document.getElementById("display").textContent;

    const li = document.createElement("li");
    li.textContent = `Lap ${lapCount} — ${time}`;
    document.getElementById("laps").appendChild(li);

    saveLap(li.textContent);
}

function saveLap(lap) {
    const laps = JSON.parse(localStorage.getItem("laps")) || [];
    laps.push(lap);
    localStorage.setItem("laps", JSON.stringify(laps));
}

function loadLaps() {
    const laps = JSON.parse(localStorage.getItem("laps")) || [];
    laps.forEach(l => {
        const li = document.createElement("li");
        li.textContent = l;
        document.getElementById("laps").appendChild(li);
    });
}

function toggleTheme() {
    document.body.classList.toggle("dark");
}

document.addEventListener("keydown", (e) => {
    if (e.key === " ") startStop();
    if (e.key === "r") reset();
    if (e.key === "l") lap();
});

loadLaps();
updateDisplay();
